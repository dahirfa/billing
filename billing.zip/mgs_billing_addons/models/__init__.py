# -*- coding: utf-8 -*-

from . import crm
from . import property
from . import res_partner
